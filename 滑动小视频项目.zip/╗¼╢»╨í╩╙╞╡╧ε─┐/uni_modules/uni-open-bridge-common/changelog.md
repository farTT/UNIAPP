## 1.0.4（2022-09-21）
- 新增 支持使用阿里云固定IP获取微信公众号H5凭据 access_token、ticket，开发者需要在微信公众平台配置阿里云固定IP，[固定IP详情](https://uniapp.dcloud.net.cn/uniCloud/cf-functions.html#aliyun-eip)
## 1.0.3（2022-09-06）
- 修复 过期时间问题，容错 AccessToken 默认 fallback 逻辑，当微信服务器没有返回过期时间时设置为2小时后过期
## 1.0.2（2022-09-02）
- 新增 依赖数据表schema opendb-open-data
## 1.0.0（2022-08-22）
- 首次发布
